﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Npgsql;
namespace Form01
{
    public partial class Form1 : Form
    {
        NpgsqlConnection con;
        string constring = "Host=localhost;Port=5432;Username=postgres;Password=1952;Database=Form1";
        
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Form is loading...");
            cbqty.Items.Clear();
            cbqty.Items.Add("1");
            cbqty.Items.Add("2");
            cbqty.Items.Add("3");
            cbqty.Items.Add("4");
            cbqty.Items.Add("5");
            cbqty.SelectedIndex = 0;

            LoginForm loginForm = new LoginForm();
            if (loginForm.ShowDialog()!=DialogResult.OK)
            {
                this.Close();
            } else
            {
                MessageBox.Show("Form is now visible");
            }

            DbConnect();
            LoadData();
        }

        void DbConnect()
        {
            try
            {
                con = new NpgsqlConnection(constring);
                con.Open();
                MessageBox.Show("Postgres Connection Success");
            }
            catch (Exception ex) { 
                MessageBox.Show("Error Postgres Connection: "+ex.Message);
            }
        }

        void LoadData()
        {
            con.Close();
            try
            {
                con.Open();
                string query = "Select * from Manage";
                NpgsqlCommand cmd = new NpgsqlCommand(query, con);

                DataTable tb = new DataTable();
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                da.Fill(tb);

                dataGridView1.DataSource = tb;

                MessageBox.Show("Data loaded");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Loading Data: "+ex.Message);
            }
        }

        bool ValidateName()
        {
            if (string.IsNullOrEmpty(tbname.Text))
            {
                MessageBox.Show("Name can't be empty");
                return false;
            }

            if (tbname.Text.Length<3)
            {
                MessageBox.Show("Name must be atleast 3 characters long.");
                return false;
            }

            if (tbname.Text.Any(Char.IsDigit))
            {
                MessageBox.Show("Name must not be numeric.");
                return false;
            }
            return true;
        }

        bool ValidateNumber()
        {
            if (string.IsNullOrEmpty(tbnumber.Text))
            {
                MessageBox.Show("Number can't be empty.");
                return false;
            }

            if (tbnumber.Text.Length < 6)
            {
                MessageBox.Show("Numbers must be atleast 6 digits long.");
                return false;
            }

            if (!tbnumber.Text.All(Char.IsDigit))
            {
                MessageBox.Show("Number must be numeric only");
                return false;
            }
            return true;
        }

        bool Price()
        {
            return Double.TryParse(tbprice.Text, out double price);
        }

        private void bsubmit_Click(object sender, EventArgs e)
        {
            if (ValidateName() && ValidateNumber())
            {
                if (Price())
                {
                    if (cbqty.SelectedIndex != -1 && (rbelec.Checked || rbgame.Checked))
                    {
                        MessageBox.Show("Validation Success");
                        string insertquery = "Insert into Manage(pname, pnumber, price, quantity, category, membership, buydate) values (@pname, @pnumber, @price, @quantity, @category, @membership, @buydate)";
                        NpgsqlCommand cmd = new NpgsqlCommand(insertquery, con);
                        cmd.Parameters.AddWithValue("@pname", tbname.Text);
                        cmd.Parameters.AddWithValue("@pnumber", long.Parse(tbnumber.Text));
                        cmd.Parameters.AddWithValue("@price", double.Parse(tbprice.Text));
                        cmd.Parameters.AddWithValue("@quantity", int.Parse(cbqty.SelectedItem.ToString()));
                        cmd.Parameters.AddWithValue("@category", rbelec.Checked ? "Electronics" : "Gaming");
                        cmd.Parameters.AddWithValue("@membership", chprime.Checked);
                        cmd.Parameters.AddWithValue("@buydate", dgv.Text.ToString());

                        int x = cmd.ExecuteNonQuery();
                        if (x > 0)
                        {
                            MessageBox.Show("Product Inserted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        } else
                        {
                            MessageBox.Show("Product Insert Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Fields must not be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                } else
                {
                    MessageBox.Show("Enter Price properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void bclear_Click(object sender, EventArgs e)
        {
            tbname.Clear();
            tbnumber.Clear();
            tbprice.Clear();
            cbqty.SelectedIndex = 0;
            rbelec.Checked = false;
            rbgame.Checked = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow r = dataGridView1.Rows[e.RowIndex];
            lbid.Text = r.Cells[0].Value.ToString();
            tbname.Text = r.Cells[1].Value.ToString();
            tbnumber.Text = r.Cells[2].Value.ToString();
            tbprice.Text = r.Cells[3].Value.ToString();
            cbqty.Text = r.Cells[4].Value.ToString();
            string c = r.Cells[5].Value.ToString();
            if (c=="Electronics")
            {
                rbelec.Checked = true;
            } else
            {
                rbgame.Checked = true;
            }

            Boolean p1 = Convert.ToBoolean(r.Cells[6].Value.ToString());
            if (p1 == true)
            {
                chprime.Checked = true;
            } else
            {
                chprime.Checked = false;
            }
            dgv.Text = r.Cells[7].Value.ToString();
        }

        private void bupdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lbid.Text) || !int.TryParse(lbid.Text, out int pid))
            {
                MessageBox.Show("Please select a product to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (ValidateName() && ValidateNumber())
            {
                if (Price())
                {
                    if (cbqty.SelectedIndex != -1 && (rbelec.Checked || rbgame.Checked))
                    {
                        MessageBox.Show("Validation Success");
                        string insertquery = "Update Manage set pname=@pname, pnumber=@pnumber, price=@price, quantity=@quantity, category=@category, membership=@membership, buydate=@buydate where pid=@pid";
                        NpgsqlCommand cmd = new NpgsqlCommand(insertquery, con);
                        cmd.Parameters.AddWithValue("@pname", tbname.Text);
                        cmd.Parameters.AddWithValue("@pnumber", long.Parse(tbnumber.Text));
                        cmd.Parameters.AddWithValue("@price", double.Parse(tbprice.Text));
                        cmd.Parameters.AddWithValue("@quantity", int.Parse(cbqty.SelectedItem.ToString()));
                        cmd.Parameters.AddWithValue("@category", rbelec.Checked ? "Electronics" : "Gaming");
                        cmd.Parameters.AddWithValue("@membership", chprime.Checked);
                        cmd.Parameters.AddWithValue("@buydate", dgv.Text.ToString());
                        cmd.Parameters.AddWithValue("@pid", int.Parse(lbid.Text));

                        int x = cmd.ExecuteNonQuery();
                        if (x > 0)
                        {
                            MessageBox.Show("Product Updated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Product Updation Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Fields must not be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Enter Price properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void bdelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lbid.Text) || !int.TryParse(lbid.Text, out int pid))
            {
                MessageBox.Show("Please select a product to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string insertquery = "Delete from Manage where pid=@pid";
            NpgsqlCommand cmd = new NpgsqlCommand(insertquery, con);
            cmd.Parameters.AddWithValue("@pid", int.Parse(lbid.Text));
            int x = cmd.ExecuteNonQuery();
            if (x > 0)
            {
                MessageBox.Show("Product Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Product Deletion Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            LoadData();

        }

        private void bsearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbsearch.Text))
            {
                MessageBox.Show("Search field can't be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                con.Close();
                try
                {
                    con.Open();
                    string query = "Select * from Manage where pname ILIKE @pname";
                    using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, con))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("@pname", "%" + tbsearch.Text + "%");
                        DataTable searchResults = new DataTable();
                        adapter.Fill(searchResults);
                        if (searchResults.Rows.Count > 0)
                        {
                            dataGridView1.DataSource = searchResults;
                        }
                        else
                        {
                            MessageBox.Show("No results found.");
                            LoadData();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error Loading Data: " + ex.Message);
                }
            }
        }
    }
}
