﻿namespace Form01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bclear = new System.Windows.Forms.Button();
            this.bsubmit = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DateTimePicker();
            this.rbgame = new System.Windows.Forms.RadioButton();
            this.rbelec = new System.Windows.Forms.RadioButton();
            this.chprime = new System.Windows.Forms.CheckBox();
            this.cbqty = new System.Windows.Forms.ComboBox();
            this.tbprice = new System.Windows.Forms.TextBox();
            this.tbnumber = new System.Windows.Forms.TextBox();
            this.tbname = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bupdate = new System.Windows.Forms.Button();
            this.bdelete = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbid = new System.Windows.Forms.Label();
            this.tbsearch = new System.Windows.Forms.TextBox();
            this.bsearch = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bclear);
            this.groupBox1.Controls.Add(this.bsubmit);
            this.groupBox1.Controls.Add(this.dgv);
            this.groupBox1.Controls.Add(this.rbgame);
            this.groupBox1.Controls.Add(this.rbelec);
            this.groupBox1.Controls.Add(this.chprime);
            this.groupBox1.Controls.Add(this.cbqty);
            this.groupBox1.Controls.Add(this.tbprice);
            this.groupBox1.Controls.Add(this.tbnumber);
            this.groupBox1.Controls.Add(this.tbname);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(36, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(433, 524);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Item Details";
            // 
            // bclear
            // 
            this.bclear.Location = new System.Drawing.Point(213, 363);
            this.bclear.Margin = new System.Windows.Forms.Padding(4);
            this.bclear.Name = "bclear";
            this.bclear.Size = new System.Drawing.Size(100, 28);
            this.bclear.TabIndex = 16;
            this.bclear.Text = "Clear";
            this.bclear.UseVisualStyleBackColor = true;
            this.bclear.Click += new System.EventHandler(this.bclear_Click);
            // 
            // bsubmit
            // 
            this.bsubmit.Location = new System.Drawing.Point(40, 363);
            this.bsubmit.Margin = new System.Windows.Forms.Padding(4);
            this.bsubmit.Name = "bsubmit";
            this.bsubmit.Size = new System.Drawing.Size(100, 28);
            this.bsubmit.TabIndex = 15;
            this.bsubmit.Text = "Submit";
            this.bsubmit.UseVisualStyleBackColor = true;
            this.bsubmit.Click += new System.EventHandler(this.bsubmit_Click);
            // 
            // dgv
            // 
            this.dgv.Location = new System.Drawing.Point(64, 306);
            this.dgv.Margin = new System.Windows.Forms.Padding(4);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(265, 22);
            this.dgv.TabIndex = 14;
            // 
            // rbgame
            // 
            this.rbgame.AutoSize = true;
            this.rbgame.Location = new System.Drawing.Point(89, 261);
            this.rbgame.Margin = new System.Windows.Forms.Padding(4);
            this.rbgame.Name = "rbgame";
            this.rbgame.Size = new System.Drawing.Size(75, 20);
            this.rbgame.TabIndex = 13;
            this.rbgame.TabStop = true;
            this.rbgame.Text = "Gaming";
            this.rbgame.UseVisualStyleBackColor = true;
            // 
            // rbelec
            // 
            this.rbelec.AutoSize = true;
            this.rbelec.Location = new System.Drawing.Point(89, 233);
            this.rbelec.Margin = new System.Windows.Forms.Padding(4);
            this.rbelec.Name = "rbelec";
            this.rbelec.Size = new System.Drawing.Size(94, 20);
            this.rbelec.TabIndex = 12;
            this.rbelec.TabStop = true;
            this.rbelec.Text = "Electronics";
            this.rbelec.UseVisualStyleBackColor = true;
            // 
            // chprime
            // 
            this.chprime.AutoSize = true;
            this.chprime.Checked = true;
            this.chprime.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chprime.Location = new System.Drawing.Point(108, 197);
            this.chprime.Margin = new System.Windows.Forms.Padding(4);
            this.chprime.Name = "chprime";
            this.chprime.Size = new System.Drawing.Size(64, 20);
            this.chprime.TabIndex = 11;
            this.chprime.Text = "Prime";
            this.chprime.UseVisualStyleBackColor = true;
            // 
            // cbqty
            // 
            this.cbqty.FormattingEnabled = true;
            this.cbqty.Location = new System.Drawing.Point(59, 151);
            this.cbqty.Margin = new System.Windows.Forms.Padding(4);
            this.cbqty.Name = "cbqty";
            this.cbqty.Size = new System.Drawing.Size(160, 24);
            this.cbqty.TabIndex = 10;
            // 
            // tbprice
            // 
            this.tbprice.Location = new System.Drawing.Point(64, 111);
            this.tbprice.Margin = new System.Windows.Forms.Padding(4);
            this.tbprice.Name = "tbprice";
            this.tbprice.Size = new System.Drawing.Size(132, 22);
            this.tbprice.TabIndex = 9;
            // 
            // tbnumber
            // 
            this.tbnumber.Location = new System.Drawing.Point(136, 70);
            this.tbnumber.Margin = new System.Windows.Forms.Padding(4);
            this.tbnumber.Name = "tbnumber";
            this.tbnumber.Size = new System.Drawing.Size(132, 22);
            this.tbnumber.TabIndex = 8;
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(124, 30);
            this.tbname.Margin = new System.Windows.Forms.Padding(4);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(132, 22);
            this.tbname.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 309);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Date :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 155);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Qty. :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 235);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Category :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 198);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Membership :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Price :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Number :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name :";
            // 
            // bupdate
            // 
            this.bupdate.Location = new System.Drawing.Point(658, 321);
            this.bupdate.Margin = new System.Windows.Forms.Padding(4);
            this.bupdate.Name = "bupdate";
            this.bupdate.Size = new System.Drawing.Size(100, 28);
            this.bupdate.TabIndex = 17;
            this.bupdate.Text = "Update";
            this.bupdate.UseVisualStyleBackColor = true;
            this.bupdate.Click += new System.EventHandler(this.bupdate_Click);
            // 
            // bdelete
            // 
            this.bdelete.Location = new System.Drawing.Point(805, 321);
            this.bdelete.Margin = new System.Windows.Forms.Padding(4);
            this.bdelete.Name = "bdelete";
            this.bdelete.Size = new System.Drawing.Size(100, 28);
            this.bdelete.TabIndex = 18;
            this.bdelete.Text = "Delete";
            this.bdelete.UseVisualStyleBackColor = true;
            this.bdelete.Click += new System.EventHandler(this.bdelete_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(527, 88);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(457, 208);
            this.dataGridView1.TabIndex = 19;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // lbid
            // 
            this.lbid.AutoSize = true;
            this.lbid.Location = new System.Drawing.Point(544, 327);
            this.lbid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbid.Name = "lbid";
            this.lbid.Size = new System.Drawing.Size(69, 16);
            this.lbid.TabIndex = 20;
            this.lbid.Text = "Product ID";
            // 
            // tbsearch
            // 
            this.tbsearch.Location = new System.Drawing.Point(527, 48);
            this.tbsearch.Name = "tbsearch";
            this.tbsearch.Size = new System.Drawing.Size(376, 22);
            this.tbsearch.TabIndex = 21;
            // 
            // bsearch
            // 
            this.bsearch.Location = new System.Drawing.Point(909, 48);
            this.bsearch.Name = "bsearch";
            this.bsearch.Size = new System.Drawing.Size(75, 23);
            this.bsearch.TabIndex = 22;
            this.bsearch.Text = "Search";
            this.bsearch.UseVisualStyleBackColor = true;
            this.bsearch.Click += new System.EventHandler(this.bsearch_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.bsearch);
            this.Controls.Add(this.tbsearch);
            this.Controls.Add(this.lbid);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bdelete);
            this.Controls.Add(this.bupdate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button bclear;
        private System.Windows.Forms.Button bsubmit;
        private System.Windows.Forms.DateTimePicker dgv;
        private System.Windows.Forms.RadioButton rbgame;
        private System.Windows.Forms.RadioButton rbelec;
        private System.Windows.Forms.CheckBox chprime;
        private System.Windows.Forms.ComboBox cbqty;
        private System.Windows.Forms.TextBox tbprice;
        private System.Windows.Forms.TextBox tbnumber;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.Button bupdate;
        private System.Windows.Forms.Button bdelete;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbid;
        private System.Windows.Forms.TextBox tbsearch;
        private System.Windows.Forms.Button bsearch;
    }
}

